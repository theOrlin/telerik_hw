﻿//NOt finished, don't bother checking

using System;

class MatrixLongestStringSequence
{
    static int checkRow(string[,] m, int x, int y)
    {
        string tempint = m[0, 0];
        int seqLen = 1;
        int tempSeq = 1;
        for (int i = x; i < m.GetLength(0); i++)
        {
            for (int j = y; j < m.GetLength(1); j++)
            {
                if (m[i, j] == tempint)
                {
                    tempSeq++;
                    if (tempSeq > seqLen)
                    {
                        
                    }
                }
            }
        }
    }
    static void Main()
    {
        string[,] strArr = new string[3, 4]
            {
                {"ha", "fifi", "ho", "hi"},
                {"fo","ha","hi","xx"},
                {"xxx", "ho", "ha", "xx"}
            };

    }
}